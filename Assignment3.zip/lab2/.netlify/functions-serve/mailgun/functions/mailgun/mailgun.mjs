
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// functions/mailgun/mailgun.mjs
import mailgun from "mailgun-js";
var mailgun_default = async (request, context) => {
  try {
    const { name, email, message, phone, subject } = await request.json();
    const mg = mailgun({ apiKey: process.env.MAILGUN, domain: process.env.MAILGUN_DOMAIN });
    const data = {
      from: `${name} + ${phone} <${email}>`,
      to: "christian.weersink+webdev@gmail.com, christian.weersink@dcmail.ca, adam.kunz@durhamcollege.ca",
      subject: `Contact Form Submission. Subject: ${subject}`,
      text: message
    };
    await mg.messages().send(data);
    return new Response(JSON.stringify({ message: "Email sent successfully!" }), {
      headers: { "Content-Type": "application/json" }
    });
  } catch (error) {
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { "Content-Type": "application/json" }
    });
  }
};
export {
  mailgun_default as default
};
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiZnVuY3Rpb25zL21haWxndW4vbWFpbGd1bi5tanMiXSwKICAic291cmNlc0NvbnRlbnQiOiBbImltcG9ydCBtYWlsZ3VuIGZyb20gXCJtYWlsZ3VuLWpzXCI7XG5cbmV4cG9ydCBkZWZhdWx0IGFzeW5jIChyZXF1ZXN0LCBjb250ZXh0KSA9PiB7XG4gIHRyeSB7XG4gICAgLy8gR2V0IGZvcm0gaW5mbyBmcm9tIHJlcXVlc3RcbiAgICBjb25zdCB7IG5hbWUsIGVtYWlsLCBtZXNzYWdlLCBwaG9uZSwgc3ViamVjdCB9ID0gYXdhaXQgcmVxdWVzdC5qc29uKCk7XG5cbiAgICBjb25zdCBtZyA9IG1haWxndW4oeyBhcGlLZXk6IHByb2Nlc3MuZW52Lk1BSUxHVU4sIGRvbWFpbjogcHJvY2Vzcy5lbnYuTUFJTEdVTl9ET01BSU4gfSk7XG4gICAgY29uc3QgZGF0YSA9IHtcbiAgICAgIGZyb206IGAke25hbWV9ICsgJHtwaG9uZX0gPCR7ZW1haWx9PmAsXG4gICAgICB0bzogXCJjaHJpc3RpYW4ud2VlcnNpbmsrd2ViZGV2QGdtYWlsLmNvbSwgY2hyaXN0aWFuLndlZXJzaW5rQGRjbWFpbC5jYSwgYWRhbS5rdW56QGR1cmhhbWNvbGxlZ2UuY2FcIixcbiAgICAgIHN1YmplY3Q6IGBDb250YWN0IEZvcm0gU3VibWlzc2lvbi4gU3ViamVjdDogJHtzdWJqZWN0fWAsXG4gICAgICB0ZXh0OiBtZXNzYWdlLFxuICAgIH07XG4gICAgLy8gU2VuZCB0aGUgZW1haWxcbiAgICBhd2FpdCBtZy5tZXNzYWdlcygpLnNlbmQoZGF0YSk7XG5cbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKEpTT04uc3RyaW5naWZ5KHsgbWVzc2FnZTogXCJFbWFpbCBzZW50IHN1Y2Nlc3NmdWxseSFcIiB9KSwge1xuICAgICAgaGVhZGVyczogeyBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9LFxuICAgIH0pO1xuICB9IGNhdGNoIChlcnJvcikge1xuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogZXJyb3IubWVzc2FnZSB9KSwge1xuICAgICAgc3RhdHVzOiA1MDAsXG4gICAgICBoZWFkZXJzOiB7IFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0sXG4gICAgfSk7XG4gIH1cbn07XG4iXSwKICAibWFwcGluZ3MiOiAiOzs7Ozs7Ozs7O0FBQUEsT0FBTyxhQUFhO0FBRXBCLElBQU8sa0JBQVEsT0FBTyxTQUFTLFlBQVk7QUFDekMsTUFBSTtBQUVGLFVBQU0sRUFBRSxNQUFNLE9BQU8sU0FBUyxPQUFPLFFBQVEsSUFBSSxNQUFNLFFBQVEsS0FBSztBQUVwRSxVQUFNLEtBQUssUUFBUSxFQUFFLFFBQVEsUUFBUSxJQUFJLFNBQVMsUUFBUSxRQUFRLElBQUksZUFBZSxDQUFDO0FBQ3RGLFVBQU0sT0FBTztBQUFBLE1BQ1gsTUFBTSxHQUFHLElBQUksTUFBTSxLQUFLLEtBQUssS0FBSztBQUFBLE1BQ2xDLElBQUk7QUFBQSxNQUNKLFNBQVMscUNBQXFDLE9BQU87QUFBQSxNQUNyRCxNQUFNO0FBQUEsSUFDUjtBQUVBLFVBQU0sR0FBRyxTQUFTLEVBQUUsS0FBSyxJQUFJO0FBRTdCLFdBQU8sSUFBSSxTQUFTLEtBQUssVUFBVSxFQUFFLFNBQVMsMkJBQTJCLENBQUMsR0FBRztBQUFBLE1BQzNFLFNBQVMsRUFBRSxnQkFBZ0IsbUJBQW1CO0FBQUEsSUFDaEQsQ0FBQztBQUFBLEVBQ0gsU0FBUyxPQUFPO0FBQ2QsV0FBTyxJQUFJLFNBQVMsS0FBSyxVQUFVLEVBQUUsT0FBTyxNQUFNLFFBQVEsQ0FBQyxHQUFHO0FBQUEsTUFDNUQsUUFBUTtBQUFBLE1BQ1IsU0FBUyxFQUFFLGdCQUFnQixtQkFBbUI7QUFBQSxJQUNoRCxDQUFDO0FBQUEsRUFDSDtBQUNGOyIsCiAgIm5hbWVzIjogW10KfQo=
