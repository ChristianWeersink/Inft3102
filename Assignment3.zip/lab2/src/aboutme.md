---
layout: layouts/default.ejs
permalink: about.html
title: About Me
---
# About me
I am Christian Weersink, and I am a third year student at Durham College, taking Computer Programming and Analysis. I enjoy mainframe development using Cobol, and also have an interest in C# game development. In my spare time I enjoy playing video games.

### Contact me
I can be contacted through email and I would love to connect on LinkedIn. Also be sure to check out some of my projects on GitHub.
- christian.weersink@dcmail.ca
- [LinkedIn](https://www.linkedin.com/in/christian-weersink/)
- [GitHub](https://github.com/ChristianWeersink)